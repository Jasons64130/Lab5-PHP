<?php
	$msg="";

	if(isset($_POST['upload'])){
		
		$allowedformats= array('jpg','jpeg','png','gif');
		$extent=strtolower(substr(($_FILES['image']['name']), strrpos($_FILES['image']['name'],'.')+1));
		echo "Here is your file:".$extent;
		
		$target= "images/".basename($_FILES['image']['name']);
		
		$error=array();
		
		if(in_array($extent,$allowedformats)===false){
			echo "Upload failed, please select other formats";
		}
		
		if($_FILES['image']['size']>10000000){
			echo "The file is over the maximum size of 10 MB, please select another file";
		}
		
		if(empty($error)){
 			move_uploaded_file($_FILES['image']['tmp_name'], "images/{$_FILES['image']['name']}");  
		}
		
		
		@ $db = mysqli_connect("localhost","root","0959","the_photo");
		
		if ($db->connect_error) {
    		echo "Acess denied: " . $db->connect_error;
   		 	printf("<br><a href=Lab-1.php>Return to home page </a>");
    		exit();
}
		
		$image= $_FILES['image']['name'];
		$text = $_POST['text'];
		
		$text = htmlentities($text);
		
		$sql = "INSERT INTO tb_images (image,text) VALUES ('$image','$text')";
		mysqli_query($db,$sql);
		
		if(move_uploaded_file($_FILES['image']['tmp_name'], $target)){
			$msg="Image uoloaded successfully";
		}else{
			$msg="Image has not been uploaded";
		}
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" tepe="text/css" href="xss.css">
<title>无标题文档</title>
</head>

<body>
<div id="content">
	<?php
 		if (isset($error)){
             if (empty($error)){  
             } else {
                  foreach ($error as $err){
                               echo $err;
                           }
                           
                       }
                   }
	
		$db = mysqli_connect("localhost","root","0959","the_photo");
	
		if ($db->connect_error) {
    	echo "Acess denied: " . $db->connect_error;
    	printf("<br><a href=Lab-1.php>Return to home page </a>");
    	exit();
}
		$sql = "SELECT * FROM tb_images";
		$result = mysqli_query($db,$sql);
		while($row = mysqli_fetch_array($result)){
			echo"<div id=img_div>";
			echo "<img src='images/".$row['image']."'>";
			echo"<p>".$row['text']."</p>";
			echo"</div>";
			
		}
	?>
	<form method="POST" action="Auploading.php" enctype="multipart/form-data"> 
		<input type="hidden" name="size" value="1000000">
		<div>
			<input type="file" name="image">
		</div>
		<div>
			<textarea name="text" cols="40" row="4" placeholder="Give your instruction"></textarea>
		</div>
		<div>
			<input type="submit" name="upload" value="submit">
		</div>
		
	</form>
	
	
</div>
</body>
</html>