<?php include('header.php');?>

<h1>My Books</h1>
<ul id="mybook">
<li>
	<img src="lpcs.jpg" class="pic3">
	<h2>Name:The Little Prince</h2><br> 
	 <h2>Price:20EUR</h2><br>
	 <h2>Amount:1</h2>
	 <input type="submit" name="submit" value="Remove">
</li>	

<li>
	<img src="oz.jpg" class="pic3">
	<h2>Name:The wonderful wizard of oz</h2><br> 
	 <h2>Price:18EUR</h2><br>
	 <h2>Amount:2</h2>
	 <input type="submit" name="submit" value="Remove">
</li>	
	
</ul>

</div>

<?php include("footer.php");?>
</div>

</body>


</html>