<?php include('header.php');?>

<ul id="bodyblock">
	<li>
	<h1>How to get start with Ubooks.com~</h1>
	<a href="#">Learn more<<</a>
	</li>
	<li>
	<h1>Earn free books or vochers here?</h1>
	<a href="#">Learn more<<</a>
	</li>
	<li>
	<h1>To find your books easily~</h1>
	<a href="#">Learn more<<</a>
	</li>
</ul>

</div>
<?php include("footer.php");?>

</div>

</body>


</html>