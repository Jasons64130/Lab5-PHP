<?php include('header.php');?>
<h1>Any Questions? Do not hesitate to Contact us~</h1>
<form id="cform">
	
Name:<br>
	<input type="text" name="name" required="true">
	<br>
    E-mail address:<br>
    <input type="email" name="name" required="true">
    <br> 
    Questions:<br>
    <input type="text" name="name" required="true"><br>
    <input type="submit" name="submit" value="Submit">
</form>

</div>

<?php include("footer.php");?>
</div>
</body>
</html>