<?php include('header.php');?>

<ul id="listbox">
	<li>
	<img src="LP.jpg" class="pic2">
	<a href="#">Lonely Planet</a>
	<p>Ever since company founders Tony and Maureen Wheeler stapled together their first guidebook after an epic trip across Asia, Lonely Planet has put travellers at the heart of everything we do, informing and inspiring them with trusted content for print and digital from experts who visit every destination.
</p>
<input type="submit" name="submit" value="Reserve" id="rbutton">
</li>

	<li>
		<img src="lpcs.jpg" class="pic2">
		<a href="#">The little Prince</a>
		<p>
The novella is one of the most-translated books in the world and was voted the best book of the 20th century in France. Translated into 300 languages and dialects,selling nearly two million copies annually with sales totaling over 140 million copies worldwide,it has become one of the best-selling books ever published.
		</p>
		<input type="submit" name="submit" value="Reserve" id="rbutton">
	</li>
	<li>
		<img src="oz.jpg" class="pic2">
		<a href="#">The wonderful wizard of oz </a>
		<p>
			The Wonderful Wizard of Oz (/ɑːz/) is an American children's novel written by author L. Frank Baum and illustrated by W. W. Denslow, originally published by the George M. Hill Company in Chicago on May 17, 1900. It has since been reprinted on numerous occasions, most often under the title The Wizard of Oz, which is the title of the popular 1902 Broadway musical adaptation as well as the iconic 1939 musical film adaptation.
		</p>
		<input type="submit" name="submit" value="Reserve" id="rbutton">
	</li>
   
    <li>
    	<img src="flipped.jpg" class="pic2">
    	<a href="#">Flipped</a>
    	<p>
    		Flipped is a romance told in two voices. The first time Juli Baker saw Bryce Loski, she flipped. The first time Bryce saw Juli, he ran. That’s pretty much the pattern for these two neighbors until the eighth grade, when, just as Juli is realizing Bryce isn’t as wonderful as she thought, Bryce is starting to see that Juli is pretty amazing. How these two teens manage to see.
    	</p>
    	<input type="submit" name="submit" value="Reserve" id="rbutton">
    </li>



</ul>

</div>

<?php include("footer.php");?>
</div>

</body>
</html>