<?php include('header.php');?>
<h1>Search Your Books here</h1>
	<p>Search by titles:</p></br>
	
	<form action="Searchbooks.php" method="GET">
	<table>
		<td>Book Titles:</td>
		<td><input type="text" name="booksearch"></td>
		<td></td>
		<td>Book Authors:</td>
		<td><input type="text" name="authorsearch"></td>
		<td></td>
		<td><input type="submit" name="submit" value="submit"></td>
		
	</table>
		
	</form>

	<h1>Book List</h1>
	
	
	<?php
	$bookList = array();
		$bookList[]=array("title"=>"Lonely planet","author"=>"Tong Wheeler");
		$bookList[]=array("title"=>"The little Prince","author"=>"Antoine de Saint-Exupéry");
		$bookList[]=array("title"=>"The wonderful wizard of oz","author"=>"L. Frank Baum");
	    $bookList[]=array("title"=>"Flipped","author"=>"Van Draanen Wendelin");
//Array plays the role of database.

	if(isset($_GET)&&!empty($_GET)){
		//check GET whether been used-whether the button being clicked
		$booksearch=trim($_GET['booksearch']);
		$authorsearch=trim($_GET['authorsearch']);
		
		$booksearch=addslashes($booksearch);
		$authorsearch=addslashes($authorsearch);
		/*trim to delete the white space and the addslashes to delete some symbol before the typed text*/
		
		$foundbook=array_search($booksearch,array_column($bookList,"title"));
		$byauthor=array_search($authorsearch,array_column($bookList,"author"));
		//to find the variable title in array
		echo '<table bgcolor="#bdc0ff" cellpadding="6">';
        echo '<tr><td>Title</td> <td>Author</td> <td>Reserve</td></tr>';
		echo $booksearch;
		echo $authorsearch;
		
		if($byauthor == FALSE&&$foundbook!==FALSE){
			//if ID exist
			$book=$bookList[$foundbook];
			$titles=$book["title"];
			$authors=$book["author"];
			//a new array to store the the searched in formation and used to print in table later
				echo "<tr>";
		echo "<td> $titles </td><td> $authors </td>";
		echo '<td><a href="reserve.php?reservation=' . urlencode($titles) . '"> Reserve </a></td>';
    	echo "</tr>";
		}
		else if($byauthor!==FALSE&&$foundbook==FALSE){
			$book=$bookList[$byauthor];
			$titles=$book["title"];
			$authors=$book["author"];
			//a new array to store the the searched in formation and used to print in table later
				echo "<tr>";
		echo "<td> $titles </td><td> $authors </td>";
		echo '<td><a href="reserve.php?reservation=' . urlencode($titles) . '"> Reserve </a></td>';
    	echo "</tr>";
			
		}
		echo"</table>";
	}else{
                echo '<table bgcolor="#bdc0ff" cellpadding="6">';
                echo '<tr><b><td>Title</td> <td>Author</td> <td>Reserve</td> </b> </tr>';
		
                foreach ($bookList as $book) {
                    $titles = $book['title'];
                    $authors = $book['author'];
                    echo "<tr>";
                    echo "<td> $titles </td><td> $authors </td>";
                    echo '<td><a href="reserve.php?reservation=' . urlencode($titles) . '"> Reserve </a></td>';
                    echo "</tr>";
                }
                echo "</table>";
            }

            $fromquery = "SELECT bookid, title, author, onloan FROM db_book";
   
	?>
	
</div>
<?php include('footer.php');?>
</div>

	
	
</body>
</html>