<?php 
	if(isset($_FILES['upload'])){
		$allowedformats= array('jpg','jpeg','png','gif');
		
		$extent=strtolower(substr(($_FILES['upload']['name']), strrpos($_FILES['upload']['name'],'.')+1));
		echo "Here is your file:".$extent;
		
		$error=array();
		
		if(in_array($extent,$allowedformats)===false){
			$error="Upload failed, please select other formats";
		}
		
		if($_FILES['upload']['size']>10000000){
			$error="The file is over the maximum size of 10 MB, please select another file";
		}
		
		if(empty($error)){
 			move_uploaded_file($_FILES['upload']['tmp_name'], "uploadedfiles/{$_FILES['upload']['name']}");  
		}
		

	}
?>
<html>
    <head>
        <title>Security - Upload</title>
           </head>
           
           <body>
           <?php
			   if(isset($error)){
				   if(empty($error)){
					   
				   }else{
					   foreach ($error as $erro){
                               echo $erro;
                           }
					   
				   }
			   }
			
			   ?>
               
<div>
<form action="" method="POST" enctype="multipart/form-data">
	<input type="file" name="upload"> </input>
	<input type="submit" value="submit"> </input>
	
</form>

</div>

</body>
</html>