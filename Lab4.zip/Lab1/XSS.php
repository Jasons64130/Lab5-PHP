<?php
function comment_adding($comment){
    
@ $conn = new mysqli('localhost', 'root', '0959', 'db_secure');

$comment= $comment;
$comment = mysqli_real_escape_string($conn, $comment);

$query = ("INSERT INTO comments(comment) VALUES ('{$comment}')");
$stmt = $conn->prepare($query);
$stmt->execute();
    
}

function comment_getting(){
    
@ $conn = new mysqli('localhost', 'root', '0959', 'db_secure');
    
$query = ("SELECT comment FROM comments");
$stmt = $conn->prepare($query);
$stmt->bind_result($result);
$stmt->execute();


    while ($stmt->fetch()) {
        echo $result;
        echo "<hr/>";
    }
}


	if (isset($_POST['comment'])) {
    	comment_adding($_POST['comment']);
}

comment_getting();


?>



<!DOCTYPE>
<html>
    <head>
        <meta http-equiv="Content_Type" content="text/html; charset=utf-8"
    </head>
    <body>
        <div>
            <hr/>
 
            <form action="" method ="POST">
                <p>
                    <textarea name="comment" rows="15" cold="70"></textarea>
                    <input type ="submit" name="Comment">
                </p>        
            </form>
        
    </body>
</html>
