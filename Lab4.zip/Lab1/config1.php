<?php 
$current_page = end(explode('/', $_SERVER['REQUEST_URI']));
$dbname = 'db_book';
$dbuser = 'root';
$dbpass = '0959';
$dbserver = 'localhost';
?>