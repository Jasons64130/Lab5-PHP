<?php
	$url = $_SERVER['REQUEST_URI'];
	$strings = explode('/',$url);
	$current_page = end($strings);

	$dbname="db_secure";
	$dbuser="root";
	$dbpass="0959";
	$dbserver="localhost";
	
?>