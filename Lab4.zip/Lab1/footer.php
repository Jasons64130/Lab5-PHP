<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" tepe="text/css" href="Lab-1.css">
<title>无标题文档</title>
</head>

<body>
<?php
	echo'
	<footer id="thefooter">
	<p2>All rights reserved by Ubook.com</p2><br>
	</footer>';		
    $nextWeek=time() + (7*24*60*60);
	echo'Now:'.date('Y-m-d')."<p>"
		
	;
	?>
</body>
</html>