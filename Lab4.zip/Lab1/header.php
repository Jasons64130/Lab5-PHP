<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" tepe="text/css" href="Lab-1.css">
</head>

<?php include('config.php');
	/*The first thing in config file is to ask the server the URI of the current page
	  The second thing here is use explode to seperate the elements in an array after"/"
	  Finally, the end function to output the last elements in the array */
	?>

<body>
<div id="wholepage">
<h1>Ubooks.com</h1>
<img src="title.jpg" class="pic">

<div id="menu1">
<a class="<?php echo($current_page =='Lab-1.php'||$current_page =='')?'active':NULL?>" href="Lab-1.php">Home</a>
<!-- only this case to check whether is empaty or not because to link to the home page the last elements can be empty either with the file name, then, if the statement is correct, link to the class-active, else say NULL and not working-->
<a class="<?php echo($current_page =='lab1-Aboutus.php')?'active':NULL?>" href="lab1-Aboutus.php">About Us</a>
<!--For other pages only link to the specific name in order to link to the page-->
<a class="<?php echo($current_page =='reserveandfound.php')?'active':NULL?>" href="reserveandfound.php">Browse Books</a>
<a class="<?php echo($current_page =='reserved.php')?'active':NULL?>" href="reserved.php">My Books</a>
<a class="<?php echo($current_page =='Lab-1Contact.php')?'active':NULL?>" href="Lab-1Contact.php">Contact</a>
<a class="<?php echo($current_page =='Sqlinjection.php')?'active':NULL?>" href="Sqlinjection.php">Gallery</a>

</div>


<div id="thebody">