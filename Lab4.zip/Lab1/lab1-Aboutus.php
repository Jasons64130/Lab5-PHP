<?php include('header.php');?>


<div id="thebody">
<h1>What is Ubook?</h1>
<p>Welcome to Ubook, Our taeget is to fullfill readers requirements for a wonderful, collective paper books in all age groups as much as we can since 2010.Book4U is a website whose function of saling both paper and PDF format and try to offer customers a wonderful shopping experience. The company has located in Frankfurt also have business brunch in Asia,America and Africa. We have 4 main storage in Kyoto, Copetown Barcelona and Frunfurt. Enjoy you time on visiting us,Thanks</p>
</div>

<?php include("footer.php");?>
	</div>
</body>
</html>