<?php
include ("config.php");


$bookid = trim($_GET['bookid']);
echo '<INPUT type="hidden" name="bookid" value=' . $bookid . '>';

$bookid = trim($_GET['bookid']);
$bookid = addslashes($bookid);

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

    if ($db->connect_error) {
        echo "could not connect: " . $db->connect_error;
        printf("<br><a href=index.php>Return to home page </a>");
        exit();
    }
    
   echo "You are reserving book with the BookID:".$bookid;

    $stmt = $db->prepare("UPDATE tb_book SET onloan=1 WHERE bookid =? ");
    $stmt->bind_param('i', $bookid);
    $stmt->execute();
    printf("<br>Book Reserved!");
    printf("<br><a href=reserveandfound.php>Search and Book more Books </a>");
    printf("<br><a href=reserved.php>Return to Reserved Books </a>");
    printf("<br><a href=Lab-1.php>Return to home page </a>");
    exit;
    

