
<?php
include("config.php");
$title = "Search books";
include("header.php");

?>

<h3>Search Your books here</h3>
<hr>
Searching by title, or by author, or both<br>
<form action="reserveandfound.php" method="POST">
    <table cellpadding="10">
        <tbody>
            <tr>
                <td>Title:</td>
                <td><INPUT type="text" name="searchtitle"></td>
            </tr>
            <tr>
                <td>Author:</td>
                <td><INPUT type="text" name="searchauthor"></td>
            </tr>
            <tr>
                <td></td>
                <td><INPUT type="submit" name="submit" value="Submit"></td>
            </tr>
        </tbody>
    </table>
</form>

<h3>Book List</h3>
<hr>
<?php

$searchtitle = "";
$searchauthor = "";

if (isset($_POST) && !empty($_POST)) {
    $searchtitle = trim($_POST['searchtitle']);
    $searchauthor = trim($_POST['searchauthor']);
}


$searchtitle = addslashes($searchtitle);
$searchauthor = addslashes($searchauthor);

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

if ($db->connect_error) {
    echo "Acess denied: " . $db->connect_error;
    printf("<br><a href=Lab-1.php>Return to home page </a>");
    exit();
}


$query = " select * from tb_book";
if ($searchtitle && !$searchauthor) { 
    $query = $query . " where title like '%" . $searchtitle . "%'";
}
if (!$searchtitle && $searchauthor) { 
    $query = $query . " where author like '%" . $searchauthor . "%'";
}
if ($searchtitle && $searchauthor) { 
    $query = $query . " where title like '%" . $searchtitle . "%' and author like '%" . $searchauthor . "%'"; 
}



    $stmt = $db->prepare($query);
    $stmt->bind_result($bookid, $title, $author, $onloan, $publishtime);
    $stmt->execute();

    echo '<table>';
    echo '<tr><b><td>Book ID</td> <td>Title</td> <td>Author</td> <td>Reserved or not</td> <td>Reserve</td> </b> </tr>';
    while ($stmt->fetch()) {
			if($onloan==0){
				$onloan="NO";
			}else{
				$onloan="Yes";
			}
        echo "<tr>";
        echo "<td>$bookid</td><td> $title </td><td> $author </td><td>$onloan</td>";
        echo '<td><a href="reserveBook.php?bookid=' . urlencode($bookid) . '"> Reserve </a></td>';
        echo "</tr>";
    }
    echo "</table>";
    ?>

<?php include("footer.php"); ?>