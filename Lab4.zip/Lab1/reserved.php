<?php
include("header.php");
include("config.php");

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

if($db->connect_error){
	echo"Access denied:".$db->connect_error;
	printf("<br><a href=Lab-1.php>Back to home page</a>");
	exit();
}
$query="select title, author, onloan, bookid from tb_book where onloan is true";

	$stmt = $db->prepare($query);
    $stmt->bind_result($title, $author, $onloan, $bookid);
    $stmt->execute();

	echo '<table>';
    echo '<tr><b><td>Book ID</td> <td>Title</td> <td>Author</td> <td>Reserved or not</td> <td>Reserve</td> </b> </tr>';
	while ($stmt->fetch()) {
        if($onloan==1){
			$onloan="Yes";
		}
            
       
        echo "<tr>";
        echo "<td> $bookid </td><td> $title </td><td> $author </td><td> $onloan </td>";
        echo '<td><a href="unreserve.php?bookid=' . urlencode($bookid) . '">Return</a></td>';
        echo "</tr>";
        
    }
    echo "</table>";
    


?>



</div>
<?php include("footer.php");?>
</div>
</body>
</html>