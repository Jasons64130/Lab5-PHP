<?php include("header.php");
	  include("config.php");

$bookid=trim($_GET['bookid']);
echo '<INPUT type="hidden" name="bookid" value=' . $bookid . '>';

$bookid = trim($_GET['bookid']);      
$bookid = addslashes($bookid);

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

if($db->connect_error){
	echo"Access denied:".$db->connect_error;
	printf("<br><a href=Lab-1.php>Back to home page</a>");
	exit();
}
echo $bookid;

$stmt = $db->prepare("UPDATE tb_book SET onloan=0 WHERE bookid = ?");
$stmt->bind_param('i',$bookid);
$stmt->execute();

printf("<br>Your book has been returned");
printf("<br><a href=reserveandfound.php>To find more books</a>");
printf("<br><a href=reserved.php>To find your reserved books</a>");
printf("<br><a href=Lab-1.php>To Home page</a>");
exit();

?>
</body>
</html>